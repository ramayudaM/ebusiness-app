<?php

namespace App\Features\Auth;

use App\Models\User;
use App\Models\CustomerProfile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthService
{
    /**
     * Register customer baru.
     *
     * @param array $data ['name', 'email', 'password']
     * @return array ['user' => User, 'token' => string]
     */
    public function register(array $data): array
    {
        // 1. Buat user baru dengan role 'customer'
        $user = User::create([
            'name'     => $data['name'],
            'email'    => $data['email'],
            'password' => Hash::make($data['password']),
            'role'     => 'customer',
        ]);

        // 2. Buat customer profile kosong (bisa diisi nanti di halaman profil)
        CustomerProfile::create([
            'user_id' => $user->id,
        ]);

        // 3. Buat Sanctum Bearer token for API
        $token = $user->createToken('auth_token')->plainTextToken;

        return [
            'user'  => $user,
            'token' => $token,
        ];
    }

    /**
     * Login user dengan email + password.
     *
     * @param string $email
     * @param string $password
     * @param bool   $remember  Untuk remember me (session lebih panjang)
     * @return array ['user' => User, 'token' => string]
     * @throws ValidationException Jika kredensial salah
     */
public function login(string $email, string $password, bool $remember = false): array
{
    $user = User::where('email', $email)->first();

    if (! $user || ! Hash::check($password, $user->password)) {
        throw ValidationException::withMessages([
            'email' => ['Email atau password salah.'],
        ]);
    }

    if ($user->trashed()) {
        throw ValidationException::withMessages([
            'email' => ['Akun ini telah dinonaktifkan.'],
        ]);
    }

    $user->tokens()->delete();

    if ($user->role === 'admin') {
        $token = $user->createToken('admin_token', ['admin'])->plainTextToken;
        $tokenType = 'admin_token';
    } else {
        $token = $user->createToken('auth_token', ['customer'])->plainTextToken;
        $tokenType = 'auth_token';
    }

    return [
        'user'       => $user,
        'token'      => $token,
        'token_type' => $tokenType,
    ];
}

    /**
     * Logout user — hapus semua token yang aktif.
     *
     * @param User $user
     * @return void
     */
    public function logout(User $user): void
    {
        // Hapus semua token Sanctum milik user ini
        $user->tokens()->delete();
    }

    /**
     * Update profil user dan customer profile.
     *
     * @param User  $user
     * @param array $data
     * @return User
     */
    public function updateProfile(User $user, array $data): User
    {
        // Update nama di tabel users jika ada
        if (isset($data['name'])) {
            $user->update(['name' => $data['name']]);
        }

        // Update atau buat customer profile
        $profileData = array_filter([
            'phone'       => $data['phone'] ?? null,
            'address'     => $data['address'] ?? null,
            'city'        => $data['city'] ?? null,
            'province'    => $data['province'] ?? null,
            'postal_code' => $data['postal_code'] ?? null,
        ], fn($v) => $v !== null);

        if (! empty($profileData)) {
            $user->customerProfile()->updateOrCreate(
                ['user_id' => $user->id],
                $profileData
            );
        }

        // Return user dengan profile terbaru
        return $user->fresh(['customerProfile']);
    }

    /**
     * Update avatar user.
     *
     * @param User $user
     * @param \Illuminate\Http\UploadedFile $file
     * @return User
     */
    public function updateAvatar(User $user, $file): User
    {
        $oldPath = $user->avatar_path;

        // 1. Hapus avatar lama jika ada
        if ($oldPath && \Illuminate\Support\Facades\Storage::disk('public')->exists($oldPath)) {
            \Illuminate\Support\Facades\Storage::disk('public')->delete($oldPath);
        }

        // 2. Simpan file baru
        $path = $file->store('avatars', 'public');

        $user->avatar_path = $path;
        $user->save();

        return $user->fresh(['customerProfile']);
    }
}
